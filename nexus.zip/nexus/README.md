# Nexus
1. Edit lib/settings.dart (replace USER/REPO with your GitHub repo that holds configs.txt).
2. Upload this folder (including .github) to a GitHub repo.
3. Actions > Build APK > Run workflow. Download the "nexus-apk" artifact.
   - app-arm64-v8a-release.apk -> most modern phones
   - app-release.apk -> universal (works everywhere, bigger)

Optional (so updates install over old versions): create a keystore with alias "nexus",
add secrets KEYSTORE_B64 (base64 of the .jks) and KEYSTORE_PASSWORD.

configs.txt: one link per line (vless/vmess/trojan/ss), or the whole file base64.
