import 'dart:async';
import 'dart:convert';
import 'package:cryptography/cryptography.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'settings.dart';

/// Requests all URLs at once and returns the first valid response.
Future<String> fetchFirst(List<String> urls) {
  final done = Completer<String>();
  var failed = 0;
  void fail() {
    failed++;
    if (failed == urls.length && !done.isCompleted) {
      done.completeError('All sources failed');
    }
  }

  for (final u in urls) {
    () async {
      try {
        final r = await http.get(Uri.parse(u)).timeout(const Duration(seconds: 8));
        if (r.statusCode == 200 && r.body.trim().isNotEmpty) {
          if (!done.isCompleted) done.complete(r.body);
        } else {
          fail();
        }
      } catch (_) {
        fail();
      }
    }();
  }
  return done.future;
}

/// Format of encrypted files: "NEXUS1:" + base64(nonce[12] + ciphertext + mac[16])
Future<String> maybeDecrypt(String body) async {
  final text = body.trim();
  if (!text.startsWith('NEXUS1:')) return text;
  final key = base64.decode(encryptionKeyBase64);
  final bytes = base64.decode(text.substring(7));
  final box = SecretBox.fromConcatenation(bytes, nonceLength: 12, macLength: 16);
  final clear = await AesGcm.with256bits().decrypt(box, secretKey: SecretKey(key));
  return utf8.decode(clear);
}

final _linkRe = RegExp(r'^(vless|vmess|trojan|ss)://');

List<String> extractLinks(String text) {
  var t = text.trim();
  if (!t.contains('://')) {
    try {
      t = utf8.decode(base64.decode(base64.normalize(t.replaceAll(RegExp(r'\s'), ''))));
    } catch (_) {}
  }
  return t.split(RegExp(r'\r?\n')).map((l) => l.trim()).where(_linkRe.hasMatch).toList();
}

/// Fetches fresh links; falls back to the last good copy saved on the phone.
Future<List<String>> loadLinks() async {
  final prefs = await SharedPreferences.getInstance();
  try {
    final body = await fetchFirst(subscriptionUrls);
    final links = extractLinks(await maybeDecrypt(body));
    if (links.isNotEmpty) {
      await prefs.setStringList('links', links);
      return links;
    }
  } catch (_) {}
  return prefs.getStringList('links') ?? [];
}
