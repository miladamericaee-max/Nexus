import 'dart:convert';

class NexusConfig {
  final String protocol, name, host, raw;
  final int port;
  int? pingMs;
  bool tested = false;
  NexusConfig(this.protocol, this.name, this.host, this.port, this.raw);
}

NexusConfig? parseLink(String link) {
  try {
    final proto = link.split('://').first;
    if (proto == 'vmess') {
      final j = jsonDecode(utf8.decode(base64.decode(base64.normalize(link.substring(8)))));
      return NexusConfig(proto, '${j['ps'] ?? j['add']}', '${j['add']}', int.parse('${j['port']}'), link);
    }
    if (proto == 'ss') {
      // ss://base64(method:pass)@host:port#name  or fully base64
      var rest = link.substring(5);
      final name = rest.contains('#') ? Uri.decodeComponent(rest.split('#').last) : '';
      rest = rest.split('#').first;
      if (!rest.contains('@')) {
        rest = utf8.decode(base64.decode(base64.normalize(rest)));
      }
      final hp = rest.split('@').last.split('?').first.split(':');
      return NexusConfig(proto, name.isEmpty ? hp[0] : name, hp[0], int.parse(hp[1]), link);
    }
    final u = Uri.parse(link);
    final name = u.fragment.isEmpty ? u.host : Uri.decodeComponent(u.fragment);
    return NexusConfig(proto, name, u.host, u.port, link);
  } catch (_) {
    return null;
  }
}
