import 'dart:async';
import 'package:flutter/material.dart';
import 'engine.dart';
import 'parser.dart';
import 'settings.dart';
import 'source.dart';

void main() => runApp(const NexusApp());

class NexusApp extends StatelessWidget {
  const NexusApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Nexus',
        theme: ThemeData.dark(useMaterial3: true),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final engine = VpnEngine();
  List<NexusConfig> configs = [];
  bool connected = false, busy = false;
  String status = 'Ready';
  Timer? timer;

  @override
  void initState() {
    super.initState();
    engine.onState = (s) {
      if (!mounted) return;
      setState(() {
        if (s.contains('DISCONNECTED')) {
          connected = false;
        } else if (s.contains('CONNECTED')) {
          connected = true;
        }
      });
    };
    () async {
      await engine.init();
      await refresh();
      if (autoConnectOnLaunch && !connected && mounted) {
        final good = configs.where((c) => c.pingMs != null).take(3).toList();
        await connectList(good.isNotEmpty ? good : configs.take(3).toList());
      }
    }();
    timer = Timer.periodic(refreshInterval, (_) {
      if (!connected && !busy) refresh();
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int _key(NexusConfig c) => c.pingMs ?? (1 << 30);

  Future<void> refresh() async {
    setState(() { busy = true; status = 'Updating servers...'; });
    try {
      final links = await loadLinks();
      final list = links.map(parseLink).whereType<NexusConfig>().toList();
      if (list.isEmpty) {
        setState(() {
          configs = [];
          status = links.isEmpty
              ? 'No links found. Check configs.txt'
              : 'Could not read ${links.length} links';
        });
        return;
      }
      setState(() { configs = list; status = 'Testing ${list.length} servers...'; });
      var working = 0;
      for (var i = 0; i < list.length && i < maxTestedLinks; i += testBatchSize) {
        final part = list.skip(i).take(testBatchSize).toList();
        final d = await Future.wait(part.map((c) => engine.delay(c.raw)));
        for (var j = 0; j < part.length; j++) {
          part[j].pingMs = d[j] > 0 ? d[j] : null;
          part[j].tested = true;
          if (part[j].pingMs != null) working++;
        }
        if (mounted) {
          setState(() => status =
              'Testing ${(i + part.length).clamp(0, list.length)}/${list.length} ($working working)');
        }
        if (working >= stopAfterWorking) break;
      }
      final ok = list.where((c) => c.pingMs != null).toList()
        ..sort((a, b) => _key(a).compareTo(_key(b)));
      final rest = list.where((c) => c.pingMs == null).toList();
      setState(() {
        configs = [...ok, ...rest].take(maxShownServers).toList();
        status = ok.isEmpty
            ? 'No server passed the test (${list.length} links). Tap one to try.'
            : '${ok.length} of ${list.length} passed, showing ${configs.length}';
      });
    } catch (_) {
      setState(() => status = 'Update failed');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> connectList(List<NexusConfig> cands) async {
    if (cands.isEmpty) return;
    setState(() { busy = true; status = 'Connecting...'; });
    if (connected) {
      engine.disconnect();
      await Future.delayed(const Duration(seconds: 1));
    }
    var done = false;
    for (final c in cands) {
      try {
        if (!await engine.connect(c.raw)) {
          setState(() => status = 'VPN permission denied');
          break;
        }
        for (var i = 0; i < 24 && !connected; i++) {
          await Future.delayed(const Duration(milliseconds: 500));
        }
        if (connected) {
          setState(() => status = 'Connected: ${c.name}');
          done = true;
          break;
        }
        engine.disconnect();
      } catch (_) {}
    }
    if (!done && !status.contains('permission')) status = 'Connection failed';
    setState(() => busy = false);
  }

  Future<void> toggle() async {
    if (connected) {
      engine.disconnect();
      setState(() => status = 'Disconnected');
      return;
    }
    if (configs.isEmpty) {
      await refresh();
      if (configs.isEmpty) return;
    }
    final good = configs.where((c) => c.pingMs != null).take(3).toList();
    await connectList(good.isNotEmpty ? good : configs.take(3).toList());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Nexus'), actions: [
          IconButton(onPressed: busy ? null : refresh, icon: const Icon(Icons.refresh)),
        ]),
        body: Column(children: [
          const SizedBox(height: 40),
          Center(
            child: GestureDetector(
              onTap: busy ? null : toggle,
              child: CircleAvatar(
                radius: 70,
                backgroundColor: connected ? Colors.green : Colors.blueGrey,
                child: busy
                    ? const CircularProgressIndicator()
                    : const Icon(Icons.power_settings_new, size: 64),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(status),
          const Divider(height: 32),
          Expanded(
            child: ListView(children: [
              for (final c in configs)
                ListTile(
                  title: Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${c.protocol} · ${c.host}'),
                  trailing: Text(
                    !c.tested ? 'untested' : (c.pingMs == null ? 'failed' : '${c.pingMs} ms'),
                    style: TextStyle(
                      color: !c.tested
                          ? Colors.grey
                          : (c.pingMs == null ? Colors.redAccent : Colors.greenAccent),
                    ),
                  ),
                  onTap: busy ? null : () => connectList([c]),
                ),
            ]),
          ),
        ]),
      );
}
