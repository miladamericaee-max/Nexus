import 'dart:async';
import 'package:flutter/material.dart';
import 'engine.dart';
import 'parser.dart';
import 'ping.dart';
import 'settings.dart';
import 'source.dart';

void main() => runApp(const NexusApp());

class NexusApp extends StatelessWidget {
  const NexusApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Nexus',
        theme: ThemeData.dark(useMaterial3: true),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final engine = VpnEngine();
  List<NexusConfig> configs = [];
  bool connected = false, busy = false;
  String status = 'Ready';
  Timer? timer;

  @override
  void initState() {
    super.initState();
    engine.onState = (s) {
      if (!mounted) return;
      setState(() {
        if (s.contains('CONNECTED') && !s.contains('DIS')) {
          connected = true;
        } else if (s.contains('DISCONNECTED')) {
          connected = false;
        }
      });
    };
    () async {
      await engine.init();
      await refresh();
    }();
    timer = Timer.periodic(refreshInterval, (_) {
      if (!connected && !busy) refresh();
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> refresh() async {
    setState(() { busy = true; status = 'Updating servers...'; });
    try {
      final links = await loadLinks();
      final list = links.map(parseLink).whereType<NexusConfig>().toList();
      await testAll(list);
      final cand = list.where((c) => c.pingMs != null).take(12).toList();
      setState(() => status = 'Testing servers...');
      final delays = await Future.wait(cand.map((c) => engine.delay(c.raw)));
      for (var i = 0; i < cand.length; i++) {
        cand[i].pingMs = delays[i] > 0 ? delays[i] : null;
      }
      final ok = cand.where((c) => c.pingMs != null).toList()
        ..sort((a, b) => a.pingMs!.compareTo(b.pingMs!));
      setState(() {
        configs = ok;
        status = ok.isEmpty ? 'No working server' : '${ok.length} servers ready';
      });
    } catch (_) {
      setState(() => status = 'Update failed');
    }
    setState(() => busy = false);
  }

  Future<void> toggle() async {
    if (connected) {
      engine.disconnect();
      setState(() => status = 'Disconnected');
      return;
    }
    if (configs.isEmpty) {
      await refresh();
      if (configs.isEmpty) return;
    }
    setState(() { busy = true; status = 'Connecting...'; });
    for (final c in configs.take(3)) {
      try {
        if (!await engine.connect(c.raw)) {
          setState(() => status = 'VPN permission denied');
          break;
        }
        for (var i = 0; i < 20 && !connected; i++) {
          await Future.delayed(const Duration(milliseconds: 500));
        }
        if (connected) {
          setState(() => status = 'Connected: ${c.name}');
          break;
        }
        engine.disconnect();
      } catch (_) {}
    }
    if (!connected && status == 'Connecting...') status = 'Connection failed';
    setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Nexus'), actions: [
          IconButton(onPressed: busy ? null : refresh, icon: const Icon(Icons.refresh)),
        ]),
        body: Column(children: [
          const SizedBox(height: 48),
          Center(
            child: GestureDetector(
              onTap: busy ? null : toggle,
              child: CircleAvatar(
                radius: 70,
                backgroundColor: connected ? Colors.green : Colors.blueGrey,
                child: busy
                    ? const CircularProgressIndicator()
                    : const Icon(Icons.power_settings_new, size: 64),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(status),
          const Divider(height: 32),
          Expanded(
            child: ListView(children: [
              for (final c in configs)
                ListTile(
                  title: Text(c.name),
                  subtitle: Text('${c.protocol} · ${c.host}'),
                  trailing: Text('${c.pingMs} ms'),
                ),
            ]),
          ),
        ]),
      );
}
