import 'dart:io';
import 'parser.dart';

Future<void> testAll(List<NexusConfig> list) async {
  await Future.wait(list.map((c) async {
    final sw = Stopwatch()..start();
    try {
      final s = await Socket.connect(c.host, c.port, timeout: const Duration(seconds: 4));
      c.pingMs = sw.elapsedMilliseconds;
      s.destroy();
    } catch (_) {
      c.pingMs = null;
    }
  }));
  list.sort((a, b) => (a.pingMs ?? 99999).compareTo(b.pingMs ?? 99999));
}
