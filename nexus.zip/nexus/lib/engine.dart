import 'dart:async';
import 'package:flutter_v2ray/flutter_v2ray.dart';

/// Wraps the Xray core plugin (VpnService runs inside the plugin).
class VpnEngine {
  void Function(String state)? onState;
  late final FlutterV2ray _v = FlutterV2ray(
    onStatusChanged: (s) => onState?.call(s.state.toString().toUpperCase()),
  );

  Future<void> init() => _v.initializeV2Ray();

  /// Real delay through the proxy in ms, or -1 if it does not work.
  Future<int> delay(String link) async {
    try {
      final p = FlutterV2ray.parseFromURL(link);
      return await _v
          .getServerDelay(config: p.getFullConfiguration())
          .timeout(const Duration(seconds: 10));
    } catch (_) {
      return -1;
    }
  }

  Future<bool> connect(String link) async {
    final p = FlutterV2ray.parseFromURL(link);
    if (!await _v.requestPermission()) return false;
    await _v.startV2Ray(
      remark: p.remark.isEmpty ? 'Nexus' : p.remark,
      config: p.getFullConfiguration(),
      blockedApps: null,
      bypassSubnets: null,
      proxyOnly: false,
    );
    return true;
  }

  void disconnect() => _v.stopV2Ray();
}
