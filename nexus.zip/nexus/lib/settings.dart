// Replace USER/REPO with your GitHub account and repository.
const subscriptionUrls = <String>[
  'https://raw.githubusercontent.com/USER/REPO/main/configs.txt',
  'https://cdn.jsdelivr.net/gh/USER/REPO@main/configs.txt',
  // 'https://your-project.pages.dev/configs.txt',
];

// Optional: base64 of a 32-byte key. Leave empty if configs.txt is not encrypted.
const encryptionKeyBase64 = '';

const refreshInterval = Duration(hours: 6);

// Connect to the fastest working server automatically when the app opens.
const autoConnectOnLaunch = true;

// How many of the fastest working servers to show in the list.
const maxShownServers = 10;

// Testing limits. The app stops testing once enough working servers are found.
const maxTestedLinks = 500;
const testBatchSize = 10;
const stopAfterWorking = 10;
