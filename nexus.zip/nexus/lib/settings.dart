// Replace USER/REPO with your GitHub account and repository.
const subscriptionUrls = <String>[
  'https://raw.githubusercontent.com/USER/REPO/main/configs.txt',
  'https://cdn.jsdelivr.net/gh/USER/REPO@main/configs.txt',
  // 'https://your-project.pages.dev/configs.txt',
];

// Optional: base64 of a 32-byte key. Leave empty if configs.txt is not encrypted.
const encryptionKeyBase64 = '';

const refreshInterval = Duration(hours: 6);
