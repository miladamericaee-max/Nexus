#!/bin/bash
set -e
flutter pub get
flutter build apk --release --no-shrink
flutter build apk --release --no-shrink --split-per-abi
